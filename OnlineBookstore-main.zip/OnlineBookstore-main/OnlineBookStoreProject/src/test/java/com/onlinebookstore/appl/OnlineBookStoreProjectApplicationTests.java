package com.onlinebookstore.appl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookStoreProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
